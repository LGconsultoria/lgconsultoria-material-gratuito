# LG CONSULTORIA FITNESS – MATERIAL GRATUITO

🚀 Bem-vindo ao repositório oficial de materiais gratuitos da LG Consultoria Fitness!

Aqui você encontra conteúdos produzidos por Luiz Gustavo – nutricionista e personal trainer com mais de 15 anos de experiência em transformação corporal e performance.

## 📚 Conteúdos Disponíveis

- Protocolos de emagrecimento e hipertrofia
- Guias sobre suplementação
- Textos motivacionais e educativos
- E-books exclusivos

Todos os materiais são 100% gratuitos e atualizados com base em evidências.

---

🔗 Siga no Instagram: [@lgconsultoriafitness](https://instagram.com/lgconsultoriafitness)

📬 Contato: lgconsultoriafitnessonline@gmail.com

🧠 Disciplina, resultado e sabor na medida certa.
